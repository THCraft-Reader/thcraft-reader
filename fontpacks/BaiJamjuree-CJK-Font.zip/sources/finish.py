"""Copy shipped BaiJamjuree line metrics into the CJK conversions and verify them.

Run from the repository root with .venv/bin/python -I.
Only the style TOC fields advanceY, ascender and descender are rewritten.
"""
import hashlib, json, struct, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from cpread import read

W = Path("build/font-new/BaiJamjuree-CJK")
OLD = Path("fontpacks/BaiJamjuree")
OUT = W / "fonts/BaiJamjuree"
OUT.mkdir(parents=True, exist_ok=True)
TOC_METRICS = 32 + 12  # styleId(1)+pad(3)+intervalCount(4)+glyphCount(4)
RANGES = {"cjk-unified": (0x4E00, 0x9FFF), "hiragana": (0x3040, 0x309F), "katakana": (0x30A0, 0x30FF),
          "cjk-punct": (0x3000, 0x303F), "hangul-syllables": (0xAC00, 0xD7AF), "hangul-jamo": (0x1100, 0x11FF),
          "hangul-compat": (0x3130, 0x318F), "fullwidth": (0xFF00, 0xFFEF), "cjk-compat": (0xF900, 0xFAFF)}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
report = []
for size in (8, 10, 12, 14, 16, 18, 20, 22, 24, 26):
    name = f"BaiJamjuree_{size}.cpfont"
    old, raw = read(OLD / name), read(W / "raw" / name)
    data = bytearray(raw["raw"])
    struct.pack_into("<Bhh", data, TOC_METRICS, old["advY"], old["asc"], old["desc"])
    (OUT / name).write_bytes(data)
    new = read(OUT / name)
    assert (new["advY"], new["asc"], new["desc"]) == (old["advY"], old["asc"], old["desc"])
    assert new["glyphs"] == raw["glyphs"] and new["kern"] == raw["kern"]
    og, ng = old["glyphs"], new["glyphs"]
    common = set(og) & set(ng)
    changed = sorted(cp for cp in common if og[cp] != ng[cp])
    dropped = sorted(set(og) - set(ng))
    assert not changed, f"{name}: existing glyphs changed {changed[:10]}"
    assert all(0xE000 <= cp <= 0xF8FF for cp in dropped), dropped
    assert old["kern"] == new["kern"] and old["lig"] == new["lig"]
    nonempty = {cp for cp, g in ng.items() if g[0] and g[1]}
    report.append({
        "size": size, "file": name, "bytes": len(data), "sha256": sha(OUT / name),
        "raw_sha256": sha(W / "raw" / name),
        "line_metrics_from_shipped": {"advanceY": old["advY"], "ascender": old["asc"], "descender": old["desc"],
                                      "shipped_sha256": sha(OLD / name)},
        "native_converter_metrics": {"advanceY": raw["advY"], "ascender": raw["asc"], "descender": raw["desc"]},
        "glyphs": len(ng), "existing_glyphs_identical": len(common),
        "dropped_unused_pua_alternates": len(dropped), "added": len(set(ng) - set(og)),
        "coverage": {k: sum(1 for cp in range(a, b + 1) if cp in ng) for k, (a, b) in RANGES.items()},
        "max_cjk_glyph_top": max(ng[cp][4] for cp in range(0x4E00, 0xA000) if cp in ng),
        "min_cjk_glyph_bottom": min(ng[cp][4] - ng[cp][1] for cp in range(0x4E00, 0xA000) if cp in ng),
    })
    print(json.dumps(report[-1]))
(W / "reports/verification.json").write_text(json.dumps(report, indent=2) + "\n")
