"""Minimal CPFont v4 reader (regular style only) for host comparison."""
import struct, sys
sys.path.insert(0, "lib/EpdFont/scripts")
from fontconvert_sdcard import GLYPH_STRUCT_FORMAT
GS = struct.calcsize(GLYPH_STRUCT_FORMAT)
def read(path):
    b = open(path, 'rb').read()
    sid, ic, gc, ay, asc, desc, kl, kr, klc, krc, lig, off = struct.unpack_from("<B3xIIBhhHHBBBI4x", b, 32)
    ivs = [struct.unpack_from("<III", b, off + 12*j) for j in range(ic)]
    goff = off + 12*ic
    glyphs = [struct.unpack_from(GLYPH_STRUCT_FORMAT, b, goff + GS*k) for k in range(gc)]
    bmp_off = goff + GS*gc + kl*3 + kr*3 + klc*krc + lig*8
    out = {}
    for s, e, o in ivs:
        for cp in range(s, e+1):
            g = glyphs[o + cp - s]
            w, h, adv, left, top, dlen, doff = g
            out[cp] = (w, h, adv, left, top, b[bmp_off+doff: bmp_off+doff+dlen])
    return dict(advY=ay, asc=asc, desc=desc, glyphs=out, kern=(kl,kr,klc,krc), lig=lig, raw=b, bmp_off=bmp_off)
