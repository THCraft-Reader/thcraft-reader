#!/bin/sh
# Reproduce BaiJamjuree + CJK raw conversions. Run from the repository root.
set -eu
W=build/font-new/BaiJamjuree-CJK
A=build/thai/assets/sources
SRC=build/thai/bai-mali-sources/BaiJamjuree/BaiJamjuree-Regular.ttf
INTERVALS='latin-ext,ipa-chars,greek,(0x0300-0x036F),punctuation,symbols,thai,arabic,cjk,hangul'
for size in 8 10 12 14 16 18 20 22 24 26; do
  .venv/bin/python lib/EpdFont/scripts/fontconvert_sdcard.py \
    --regular "$SRC" --name BaiJamjuree --sizes "$size" --intervals "$INTERVALS" \
    --fallback-regular $A/noto-sans-fallback/NotoSans-Regular.ttf \
    --fallback-regular $A/notosanssymbols/regular.ttf \
    --fallback-regular $A/notosanssymbols2/regular.ttf \
    --fallback-regular $A/notosansmath/regular.ttf \
    --fallback-regular $A/NotoSansArabic/regular.ttf \
    --fallback-regular $A/noto-sans-cjk-jp/regular.otf \
    --output-dir $W/raw > $W/reports/BaiJamjuree_$size.conversion.log 2>&1 &
done
wait
