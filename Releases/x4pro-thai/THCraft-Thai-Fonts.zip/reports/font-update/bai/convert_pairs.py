#!/usr/bin/env python3
"""Convert and structurally validate the six derived Bai Jamjuree font pairs."""
import json
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / "scripts"))
sys.path.insert(0, str(ROOT / "lib/EpdFont/scripts"))
from package_thai_fonts import CONVERTER, INTERVALS, SIZES, digest, file_record, load_sources, save_json, validate_pair
from thai_shape import contexts
import uharfbuzz as hb

OUTPUT = Path(__file__).resolve().parent
ORIGINAL = ROOT / "build/thai/bai-mali-sources/BaiJamjuree/BaiJamjuree-Regular.ttf"
DERIVED = OUTPUT / "BaiJamjuree-Regular-StackSpacing.ttf"
ASSETS = ROOT / "build/thai/assets"


def shaping_font(path):
    font = hb.Font(hb.Face(path.read_bytes()))
    hb.ot_font_set_funcs(font)
    font.scale = (1000, 1000)
    return font


def shape(font, text):
    buffer = hb.Buffer()
    buffer.add_codepoints(list(text))
    buffer.script, buffer.language, buffer.direction = "thai", "th", "ltr"
    hb.shape(font, buffer)
    return [(i.codepoint, p.x_advance, p.y_advance, p.x_offset, p.y_offset)
            for i, p in zip(buffer.glyph_infos, buffer.glyph_positions)]


def main():
    old, new = shaping_font(ORIGINAL), shaping_font(DERIVED)
    changed = []
    for key, text in enumerate(contexts()):
        before, after = shape(old, text), shape(new, text)
        assert len(before) == len(after)
        targeted = (len(text) == 3 and text[1] in (0xE31, 0xE34, 0xE35, 0xE36, 0xE37)
                    and 0xE48 <= text[2] <= 0xE4B)
        if targeted:
            assert before[:-1] == after[:-1]
            assert before[-1][:-1] == after[-1][:-1]
            assert after[-1][-1] - before[-1][-1] == 50
            changed.append(key)
        else:
            assert before == after, (key, text, before, after)
    assert len(changed) == 920
    evidence = {"dense_contexts": 3772, "changed_contexts": len(changed),
                "unchanged_contexts": 3772 - len(changed),
                "all_advances_and_x_offsets_unchanged": True,
                "only_terminal_tone_y_offset_changes": True,
                "font_unit_y_shift": 50,
                "sample": {word: {"original": shape(old, map(ord, word)),
                                   "derived": shape(new, map(ord, word))}
                           for word in ("ทั้ง", "ทิ้", "ที่", "ทึ๊", "ทื๋", "ปั้", "ท้", "ทั", "ทุ้", "ทั์")}}
    save_json(OUTPUT / "reports/shaping-inspection.json", evidence)
    _, fallbacks = load_sources(ASSETS)
    family = OUTPUT / "fonts/BaiJamjuree"
    family.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ORIGINAL.with_name("OFL.txt"), family / "OFL.txt")
    for fallback in fallbacks:
        shutil.copyfile(ASSETS / fallback["license"], family / f"{fallback['name']}-OFL.txt")
    source = {"regular": str(DERIVED.relative_to(ROOT)), "regular_sha256": digest(DERIVED)}
    pairs, commands = [], []
    for size in SIZES:
        cpfont = family / f"BaiJamjuree_{size}.cpfont"
        command = [sys.executable, str(CONVERTER), "--regular", str(DERIVED),
                   "--intervals", INTERVALS, "--size", str(size), "--thai-shaping", "--output", str(cpfont)]
        for fallback in fallbacks:
            command.extend(["--fallback-regular", str(ASSETS / fallback["path"])])
        commands.append(command)
        subprocess.run(command, cwd=ROOT, check=True)
        report, styles = validate_pair(cpfont, source, size, fallbacks)
        report_path = OUTPUT / "reports" / f"BaiJamjuree_{size}.cpshape.json"
        save_json(report_path, report)
        cpfont.with_suffix(".cpshape.json").unlink()
        pairs.append({"point_size": size, "style_count": styles,
                      "cpfont": file_record(cpfont, OUTPUT),
                      "cpshape": file_record(cpfont.with_suffix(".cpshape"), OUTPUT),
                      "report": str(report_path.relative_to(OUTPUT))})
    save_json(OUTPUT / "build-report.json", {
        "dpi": 150, "style": "regular", "sizes": list(SIZES), "intervals": INTERVALS,
        "source": source, "source_provenance": "source-provenance.json", "fallbacks": fallbacks,
        "manifest_sha256": digest(ASSETS / "manifest.json"),
        "converter_sha256": digest(CONVERTER), "shaping_converter_sha256": digest(CONVERTER.with_name("thai_shape.py")),
        "commands": commands, "pairs": pairs, "shaping_inspection": evidence,
    })
    print(json.dumps({"pairs_validated": len(pairs), "shaping_inspection": evidence}, ensure_ascii=False))


if __name__ == "__main__":
    main()
