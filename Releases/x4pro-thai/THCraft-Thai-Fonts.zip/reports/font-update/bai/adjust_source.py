#!/usr/bin/env python3
"""Derive Bai Jamjuree with 50 UPEM-units extra vowel-to-tone clearance.

Run from the checkout root with .venv/bin/python. Only GPOS is modified;
the shared mkmk class is split so non-tone attachments keep their anchors.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path

from fontTools.ttLib import TTFont

ROOT = Path(__file__).resolve().parents[4]
SOURCE = ROOT / "build/thai/bai-mali-sources/BaiJamjuree/BaiJamjuree-Regular.ttf"
OUTPUT = Path(__file__).resolve().parent
DERIVED = OUTPUT / "BaiJamjuree-Regular-StackSpacing.ttf"
SHIFT = 50


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    font = TTFont(SOURCE, recalcTimestamp=False)
    assert font["head"].unitsPerEm == 1000
    lookup = font["GPOS"].table.LookupList.Lookup[9]
    assert lookup.LookupType == 6 and lookup.LookupFlag == 512
    assert len(lookup.SubTable) == 1
    sub = lookup.SubTable[0]
    assert sub.ClassCount == 1
    vowel_names = {f"uni{cp:04X}{suffix}" for cp in (0xE31, 0xE34, 0xE35, 0xE36, 0xE37)
                   for suffix in ("", ".narrow")}
    tones = {f"uni{cp:04X}{suffix}" for cp in range(0xE48, 0xE4C)
             for suffix in ("", ".small", ".narrow")}
    assert vowel_names <= set(sub.Mark2Coverage.glyphs)
    assert tones <= set(sub.Mark1Coverage.glyphs)
    class_changes = []
    for name, record in zip(sub.Mark1Coverage.glyphs, sub.Mark1Array.MarkRecord):
        assert record.Class == 0
        if name in tones:
            record.Class = 1
            class_changes.append({"glyph": name, "old_class": 0, "new_class": 1})
    anchor_changes = []
    for name, record in zip(sub.Mark2Coverage.glyphs, sub.Mark2Array.Mark2Record):
        original = record.Mark2Anchor[0]
        anchor = deepcopy(original)
        if name in vowel_names:
            assert anchor is not None and anchor.Format == 1
            anchor.YCoordinate += SHIFT
            anchor_changes.append({"glyph": name, "class": 1,
                                   "original": [original.XCoordinate, original.YCoordinate],
                                   "modified": [anchor.XCoordinate, anchor.YCoordinate]})
        record.Mark2Anchor.append(anchor)
    sub.ClassCount = 2
    font.save(DERIVED)
    with TTFont(SOURCE) as original, TTFont(DERIVED) as derived:
        assert original.keys() == derived.keys()
        changed_tables = [tag for tag in original.reader.keys()
                          if original.reader[tag] != derived.reader[tag]]
        assert set(changed_tables) == {"GPOS", "head"}, changed_tables
        assert original["hmtx"].metrics == derived["hmtx"].metrics
    report = {
        "source": str(SOURCE.relative_to(ROOT)), "source_sha256": sha(SOURCE),
        "derived": str(DERIVED.relative_to(ROOT)), "derived_sha256": sha(DERIVED),
        "script_sha256": sha(Path(__file__)), "units_per_em": 1000,
        "shift_font_units": SHIFT, "lookup": 9, "subtable": 0,
        "mechanism": "GPOS mkmk MarkMarkPos: split tone marks U+0E48..U+0E4B and their small/narrow variants into class 1; copy every Mark2 anchor and raise only mai han akat and U+0E34..U+0E37 regular/narrow class-1 anchors. Class-0 anchors, all non-target attachment anchors and Mark1 anchors unchanged.",
        "changed_tables": changed_tables,
        "preserved": ["glyph outlines", "hmtx advances and side bearings", "GSUB", "cmap", "font metrics", "mark-to-base positioning", "single marks", "other fonts"],
        "mark1_class_changes": class_changes, "anchor_changes": anchor_changes,
        "pixel_shift_at_150dpi": {str(size): SHIFT / 1000 * size * 150 / 72
                                  for size in (8, 10, 12, 14, 16, 18)},
    }
    (OUTPUT / "source-provenance.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
